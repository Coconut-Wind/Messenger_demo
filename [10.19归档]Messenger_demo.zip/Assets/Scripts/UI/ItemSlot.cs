using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemSlot : MonoBehaviour
{
    public string itemName = "Null";
    public string description = "description"; //道具描述，鼠标悬停于上方时显示
    public string usedDesc = "balabala"; //道具使用后弹出的提示

    public void SetSprite(Sprite sp)
    {
        GetComponent<Image>().sprite = sp;
    } 

    public void SetInfo(string itemName, string description = "", string usedDesc = "")
    {
        this.itemName = itemName;
        this.description = description!=""?description:this.description;
        this.usedDesc = usedDesc!=""?usedDesc:this.usedDesc;
    }

    public void OnClicked()
    {
        GameManager.instance.UseItem(itemName, usedDesc);
        Destroy(gameObject);
    }
}
