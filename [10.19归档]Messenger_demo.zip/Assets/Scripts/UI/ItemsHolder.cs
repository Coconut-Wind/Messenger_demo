using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemsHolder : MonoBehaviour
{
    public int maxSlotsCount = 5;
    public GameObject slotPrefabs;
    public Sprite[] itemIcos;

    public void AddItem(string itemName, string description="", string usedDesc = "")
    {
        if (transform.childCount < maxSlotsCount){
            GameObject tmp = Instantiate(slotPrefabs);
            ItemSlot slot = tmp.GetComponent<ItemSlot>();
            
            slot.SetInfo(itemName, description, usedDesc);
            tmp.transform.SetParent(this.transform);

            foreach (Sprite sp in itemIcos)
            {
                if (sp.name == name)
                {
                    slot.SetSprite(sp);
                }
            }
        }
    }

    public void ClearAll()
    {
        for (int i = 0; i < transform.childCount; i++)
        {
            Destroy(transform.GetChild(i).gameObject);
        }
    }
}
